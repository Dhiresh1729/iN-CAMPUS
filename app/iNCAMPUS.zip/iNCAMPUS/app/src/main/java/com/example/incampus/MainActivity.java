package com.example.incampus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText userName, firstName, lastName, emailId;
    private TextView welcomeTxt;
    private Button logOutBtn;
    private FirebaseAuth mAuth;
    FirebaseDatabase  firebaseDatabase;
    DatabaseReference databaseReference;
    private String firstname, lastname, username, email, welcomeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

        firstName = findViewById(R.id.edtFirstName);
        lastName = findViewById(R.id.edtLastName);
        userName = findViewById(R.id.edtUserName);
        emailId = findViewById(R.id.edtEmailId);
        welcomeTxt = findViewById(R.id.txtWelcome);
        logOutBtn = findViewById(R.id.btnLogOut);
        mAuth = FirebaseAuth.getInstance();

        getdata();


        logOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent i = new Intent(MainActivity.this, LogIn.class);
                startActivity(i);
                finish();
                Toast.makeText(MainActivity.this, "User logged out Successfully", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void getdata() {
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = firebaseDatabase.getReference();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        String userKey = user.getUid();
        System.out.println("userKey: " + userKey);

        databaseReference.child("users").child(userKey).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                String username = (String) snapshot.child("userName").getValue();
                String firstname = (String) snapshot.child("firstName").getValue();
                String lastname = (String) snapshot.child("lastName").getValue();
                String email = (String) snapshot.child("emailId").getValue();
                String welcomeText = "WELCOME " + firstname + " " + lastname;

                System.out.println("FIRST_NAME: " + firstname);
                System.out.println("LAST_NAME: " + lastname);
                System.out.println("USER_NAME: " + username);
                System.out.println("EMAIL: " + email);

                firstName.setText(firstname);
                lastName.setText(lastname);
                userName.setText(username);
                emailId.setText(email);
                welcomeTxt.setText(welcomeText);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }



}