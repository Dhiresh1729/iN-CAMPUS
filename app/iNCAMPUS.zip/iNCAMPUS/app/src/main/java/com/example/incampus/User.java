package com.example.incampus;

public class User {

    public String firstName, lastName, userName, emailId;

    public User(String firstName, String lastName, String userName, String emailId) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.emailId = emailId;
    }





}
